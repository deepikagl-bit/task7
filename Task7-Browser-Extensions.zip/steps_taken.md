### Steps Taken During Task 7

1. Opened **Chrome → Extensions (chrome://extensions/)**.  
2. Opened **Firefox → Add-ons Manager (about:addons)**.  
3. Carefully checked permissions of each installed extension.  
4. Compared extensions with trusted sources online.  
5. Removed suspicious and unnecessary extensions.  
6. Restarted browser and confirmed smoother performance.  
7. Documented removed extensions in `suspicious_extensions.txt`.
